//===========================================================================================
// Name        : LinkedList.cpp
// Author      : Avery Lutz
// Date        : June 19, 2022
// Class       : CS-499-T5649
// Artifact    : Two
// Version     : 2.0
// Ability     : Data Structures and Algorithms
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Utilize a linked list to manage contents of an Excel spreadsheet.
// Features    : Load a list of bids, add new bids, update, delete, and find existing bids.
//===========================================================================================

#include <algorithm>
#include <iostream>
#include <time.h>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// Forward declarations.
double strToDouble(string str, char ch);

// Define a structure to hold bid information.
	struct Bid {
    string bidId;              // Unique identifier.
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

//============================================================================
// Linked-List class definition
//============================================================================

// Define a class containing data members and methods to
//  Implement a linked-list.
class LinkedList {

private:
    // Internal structure for list entries, housekeeping variables.
	struct Node {
		Bid bid;
		Node* next;

		// Default constructor.
		Node() {
			next = nullptr;
		}

		// Initialize a node with a bid.
		Node(Bid theBid) {
			bid = theBid;
			next = nullptr;
		}

	};
	// Define a node pointer for the head and tail variables.
	Node* head;
	Node* tail;
	int size = 0;

public:
    LinkedList();
    virtual ~LinkedList();
    void Append(Bid bid);
    void Prepend(Bid bid);
    void Update(Bid bid);
    void PrintList();
    void Remove(string bidId);
    Bid Search(string bidId);
    int Size();
};


// Default constructor.
LinkedList::LinkedList() {
    // Initialize housekeeping variables.
	head = tail = nullptr;
}


// Destructor.
LinkedList::~LinkedList() {
}


// Append a new bid to the end of the list.
void LinkedList::Append(Bid bid) {
    // Implement append logic.
	Node* node = new Node(bid);

	// Ensure whether the bid to be appended is the first bid or not.
	if (head == nullptr){
		head = node;
	}else {
		if (tail != nullptr){
			tail -> next = node;
		}
	}
	// New nodes will always become the tail.
	// The size must increase to include the addition of new nodes.
	tail = node;
	size++;
}


// Prepend a new bid to the start of the list.
void LinkedList::Prepend(Bid bid) {
    // Implement prepend logic.
	Node* node = new Node(bid);

	// Make the next node equal the current head node.
	if (head != nullptr){
		node->next = head;
	}
	head = node;
	size++;
}


void LinkedList::Update(Bid bid){

	string userOption;                                     // The user's selection for field modification.
	string update;                                         // The update for the new field.
	string correctID = bid.bidId;                          // Variable to match against node.

	// Ask the user which field they would like to change.
	cout << "Please select one of the following options by typing a 1, 2, or 3:" << endl;
	cout << "1. Update the bid's title." << endl;
	cout << "2. Update the bid's fund." << endl;
	cout << "3. Update the bid's amount." << endl;
	cin >> userOption;

	Node* currentBid = head;

    // Loop through nodes to find a match.
	while (currentBid != nullptr){
		if (currentBid->bid.bidId.compare(correctID)==0){
			if (userOption == "1") {
				cout <<"Please enter the selected bid's new title: " << endl;
				cin.ignore();
				getline(cin, update);
				currentBid->bid.title = update;                   // Update the bid's title.
			}
			else if (userOption == "2" ) {
				cout <<"Please enter the selected bid's new fund: " << endl;
				cin.ignore();
				getline(cin, update);
				currentBid->bid.fund = update;                     // Update the selected bid's fund.
			}
			else if (userOption == "3") {
				cout <<"Please enter the selected bid's new amount: " << endl;
				cin >> update;
				currentBid->bid.amount = strToDouble(update, '$'); // Update the bid's amount.
			}
			 // User selected an invalid choice.
			else{
				cout <<"Sorry, your input was unrecognizable. Please try again." << endl;
			}
		}
		// Go to the next node in the list if the current node was not correct.
		currentBid = currentBid->next;
	}
}


// Simple output of all bids in the list.
void LinkedList::PrintList() {
    // Implement print logic.
	Node* currentBid = head;
	cout << head;
	// Loop through nodes to find a match.
	while (currentBid != nullptr) {
		cout << currentBid ->bid.bidId << ": " << currentBid ->bid.title << " | "
			 << currentBid ->bid.amount << " | " << currentBid ->bid.fund << endl;
		currentBid = currentBid->next;
	}
}


// Remove a specified bid.
// @param bidId The bid id to remove from the list.
void LinkedList::Remove(string bidId) {
    // Implement remove logic.
	if (head != nullptr){
		if(head->bid.bidId.compare(bidId)==0){

			// Use temporary node to save the value.
			Node* tempNode = head->next;
			delete head;
			head = tempNode;
		}
	}
	Node* currentBid = head;

	// Loop through nodes to find a match.
	while (currentBid->next != nullptr) {
		if (currentBid->next->bid.bidId.compare(bidId)==0) {
			// Save the next node, the one to be removed.
			Node* tempNode = currentBid->next;

			// Make current node point past next node.
			currentBid->next = tempNode->next;

			// Delete temporary node and reduce list size.
			delete tempNode;
			size--;

			cout << "Bid was successfully deleted." << endl;
			return;
		}
		currentBid = currentBid->next;
	}
	cout << "The bid with an ID of " + bidId +" does not exist." << endl;
}


// Search for the specified bidId
// @param bidId The bid id to search for.
Bid LinkedList::Search(string bidId) {

	Bid bid;

    // Implement search logic.
	Node* currentBid = head;

	// Loop through nodes to find a match.
	while (currentBid != nullptr) {
		if (currentBid->bid.bidId.compare(bidId)==0) {
			return currentBid->bid;
		}
		// Make current bid the next bid in the list.
		currentBid = currentBid->next;
	}
	return bid;
}

// Returns the current size (number of elements) in the list.
int LinkedList::Size() {
    return size;
}

//============================================================================
// Static methods used for testing
//============================================================================


// Display the bid information
// @param bid struct containing the bid info.
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount
         << " | " << bid.fund << endl;
    return;
}

// Prompt user for bid information4
// @return Bid struct containing the bid info.
Bid getBid() {
    Bid bid;
    string strAmount;

    // Obtain the new bid's ID & set into structure.
    cout << "What is the ID of the bid you would like to enter? ";
    cin.ignore();
    getline(cin, bid.bidId);
	cout << "\nWhat is the title of the bid you would like to enter? " << endl;
	getline(cin, bid.title);
	cout << "What is the fund of the bid you would like to enter? " << endl;
	getline(cin, bid.fund);
	cout << "What is the amount of the bid you would like to enter? (please exclude $) " << endl;
	cin >> strAmount;
	bid.amount = strToDouble(strAmount, '$');;

    return bid;
}

// Load a CSV file containing bids into a LinkedList
// @return a LinkedList containing all the bids read.
int loadBids(string csvPath, LinkedList *list) {
    cout << "Loading CSV file " << endl << csvPath << endl;

    csv::Parser file = csv::Parser(csvPath);           // Initialize the CSV Parser.

    try {
        // Loop to read rows of a CSV file.
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Initialize a bid using data from current row (i).
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            // Add this bid to the end.
            list->Append(bid);
        }
    } catch (csv::Error &e) {
        std::cerr << e.what() << std::endl;
    }
    return 1;
}


// Simple C function to convert a string to a double
// after stripping out unwanted char
// credit: http://stackoverflow.com/a/24875936
// @param ch The character to strip out.
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

// The one and only main() method.
// @param arg[1] path to CSV file to load from (optional).
// @param arg[2] the bid Id to use when searching the list (optional).
int main(int argc, char* argv[]) {

    // Process command line arguments.
    string csvPath, bidKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        bidKey = "98109";
        break;
    case 3:
        csvPath = argv[1];
        bidKey = argv[2];
        break;
    default:
        csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
        bidKey = "98109";
    }

    clock_t ticks;                       // Define variables needed in main.
    LinkedList bidList;                  // Define a Linked List to store the bids.
    Bid bid;                             // Define a Bid data structure.
    string updateBid;                    // Define an integer for the user to update a bid.
    int bidsAreLoaded = 0;               // Define a variable to determine if bids were loaded.

    // While loop to correctly match user's input.
    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Find Bid" << endl;
        cout << "  4. Remove Bid" << endl;
        cout << "  5. Add a Bid" << endl;
        cout << "  6. Update a Bid" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            ticks = clock();
            // Make output neater with a space between user entry and result displayed.
            cout << endl;

            // Read csv file and 'count' the number of bids.
            bidsAreLoaded = loadBids(csvPath, &bidList);
            cout << endl;
            cout << bidList.Size() << " bids read" << endl;

            // Display the clock ticks and seconds required to load list.
            ticks = clock() - ticks; // Current clock ticks minus starting clock ticks.
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            cout << endl;

            break;

        case 2:
        	// Make output neater with spaces.
        	if (bidsAreLoaded == 1){
        		cout << endl;
        		bidList.PrintList();
        		cout << endl;
        	}
        	// Ensure all bids are loaded in.
        	else {
        		cout << "PLease load bids first." << endl;
        	}

            break;

        case 3:
            ticks = clock();

            if (bidsAreLoaded == 1){
            	// Include spaces for neatness.
            	cout << endl;

            	// Determine which bid the user would like to find.
            	cout << "Please enter the ID for the bid you would like to find: " << endl;
            	cin >> bidKey;
            	bid = bidList.Search(bidKey);

            	// Current clock ticks minus starting clock ticks.
            	ticks = clock() - ticks;

            	// Ensure the bid actually exists.
            	if (!bid.bidId.empty()) {
            		displayBid(bid);
            	} else {
            		cout << "Bid Id " << bidKey << " not found." << endl;
            	}

            	// Display the clock ticks required to find the bid.
            	cout << endl;
            	cout << "time: " << ticks << " clock ticks" << endl;
            	cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            	cout << endl;
        	}
            // Ensure Bids are loaded first.
        	else {
        		cout << "PLease load bids first." << endl;
        	}

            break;

        case 4:
        	if (bidsAreLoaded == 1){

        		cout << "Please enter the ID for the bid you would like to remove: " << endl;
        		cin >> bidKey;

        		// Goes to Remove function.
        		bidList.Remove(bidKey);
        	}
        	else {
        		cout << "PLease load bids first." << endl;
        	}
            break;

        case 5:
        	if (bidsAreLoaded == 1){
        		bid = getBid();                           // Obtain the new bid's information.
        		bidList.Append(bid);                      // Go to append function to include the new bid.
        		displayBid(bid);
    		}
        	else {
        		cout << "PLease load bids first." << endl;
        	}
            break;

        case 6:
        	if (bidsAreLoaded == 1){
        		cout << "What bid would you like to update." << endl;
        		cin >> updateBid;                                         // Obtain user input for bid to update.
        		bid = bidList.Search(updateBid);                          // Find bid to update.

        		if (!bid.bidId.empty()) {                                 // Ensure the bid actually exists.
        			displayBid(bid);
        			bidList.Update(bid);

        		}
        		else {
        			cout << "Bid Id " << updateBid << " not found." << endl;
        		}
        	}
        	else {
        		cout << "PLease load bids first." << endl;
        	}
        	break;

        case 9:
        	break;         // User is ready to exit the program.

        default:
        	// User entered an option that could not be recognized.
        	cout << "\nSorry, we could not recognize your input. Please try again." << endl;
        	break;
        }
    }
    // User wants to exit the program.
    cout << "Goodbye!!!" << endl;

    return 0;
}
