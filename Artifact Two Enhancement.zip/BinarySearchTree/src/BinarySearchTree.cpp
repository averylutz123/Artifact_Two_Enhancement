//============================================================================================
// Name        : BinarySearchTree.cpp
// Author      : Avery Lutz
// Date        : June 19, 2022
// Class       : CS-499-T5649
// Artifact    : Two
// Version     : 2.0
// Ability     : Data Structures and Algorithms
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Utilize a binary search tree to manage contents of an Excel spreadsheet.
// Features    : Load a list of bids, add new bids, update, delete, and find existing bids.
//============================================================================================

#include <algorithm>                       // Must include for strToDouble to work.
#include <iostream>
#include <time.h>
#include <string>
#include <stdlib.h>
#include<exception>

#include "CSVparser.hpp"

using namespace std;

//===============================================================
// Global definitions visible to all methods and classes
//===============================================================

// Forward declarations.
double strToDouble(string str, char ch);

// Define a structure to hold bid information.
struct Bid {
    string bidId;       // Unique identifier.
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

// Internal structure for tree node.
struct Node {
	Bid bid;
	Node* left;
	Node* right;

	// Default Constructor.
	Node() {
		left = nullptr;
		right = nullptr;
	}

	// Initialize second constructor with a bid.
	Node(Bid abid) : Node() {
		this -> bid = abid;
	}
};

//=====================================================
// Binary Search Tree class definition
//=====================================================

// Define a class containing data members and
// methods to implement a binary search tree.
class BinarySearchTree {

private:                                               // Declaration of private functions.
    Node* root;
    void addNode(Node* node, Bid bid);
    void inOrder(Node* node);
    Node* removeNode(Node* node, string bidId);

public:                                                // Declaration of public functions.
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    int createBid(int largestValue);
    void Update(Bid bid);
    void Insert(Bid bid);
    void Remove(string bidId);
    Bid Search(string bidId);
    void Size(int number);
};

// Default constructor.
BinarySearchTree::BinarySearchTree() {
    // Initialize housekeeping variables.
	root = nullptr;
}

// Destructor.
BinarySearchTree::~BinarySearchTree() {
    // Recurse from root deleting every node.
}

// Traverse the tree in order.
void BinarySearchTree::InOrder() {
	this -> inOrder(root);
}


// Insert a bid.
void BinarySearchTree::Insert(Bid bid) {
	if (root == nullptr){                    // Create a new node with passed in bid information.
		root = new Node(bid);
	}
	else {                                   // Call addNode method.
		this -> addNode(root, bid);
	}
}


// Remove a bid from the tree.
void BinarySearchTree::Remove(string bidId) {
	this -> removeNode(root, bidId);
}


// Search for a bid.
Bid BinarySearchTree::Search(string bidId) {
	// Begin searching at the top of tree, the root.
	Node* current = root;

	// Loop until bid is found or tree ends.
	while(current != nullptr) {

		// If its the current node.
		if(current -> bid.bidId.compare(bidId)== 0) {
			return current -> bid;
		}

		// If bid is smaller than the current one, go left.
		if (bidId.compare(current -> bid.bidId) < 0) {
			current = current -> left;
		} // If its larger, go right.
		else {
			current = current -> right;
		}
	}

	Bid bid;
    return bid;
}

// Add a bid to some node (recursive).
// @param node Current node in tree.
// @param bid Bid to be added.
void BinarySearchTree::addNode(Node* node, Bid bid) {
    // Insert a bid into the tree with given node.

	// If the node is larger than the bid, add to left subtree.
	if (node -> bid.bidId.compare(bid.bidId)>0){
		if (node -> left == nullptr){
			node -> left = new Node(bid);
		}else{
			this -> addNode(node -> left, bid);
		}
	} // Add to right subtree if not.
	else{
		if (node -> right == nullptr){
			node -> right = new Node(bid);
		}else{
			this -> addNode(node -> right, bid);
		}
	}
}

void displayBid(Bid bid); // Prototype for createBid method.

// Allow users to add a new bid to the existing list.
int BinarySearchTree::createBid(int largestValue){

	// Declare the variables required for method.
	string amount;
	int newLargest = (largestValue + 1);
	Bid bid;

	// Obtain the different bid categories from the user.
	bid.bidId = to_string(newLargest);
	cout << "\nWhat is the title of the bid you would like to enter? " << endl;
	cin.ignore();
	getline(cin, bid.title);
	cout << "What is the fund of the bid you would like to enter? " << endl;
	getline(cin, bid.fund);
	cout << "What is the amount of the bid you would like to enter? (please exclude $) " << endl;
	cin >> amount;
	bid.amount = strToDouble(amount, '$');;

	// Display new bid to the user & add bid to the existing bst.
	cout << "Here is your new Bid: " << endl;
	displayBid(bid);
	Insert(bid);

	// Return the new largest bid ID for future use.
	return newLargest;
}


// Update bids determined by the user.
void BinarySearchTree::Update(Bid bid){

	Node* current = root;                    // Begin searching at the top of tree, the root.
	string userOption;                       // The user's selection for field modification.
	string update;                           // The update for the new field.
	string correctID = bid.bidId;            // Variable to match against node.

	// Ask the user which field they would like to change & store their response.
	cout << "Please select one of the following options by typing a 1, 2, or 3:" << endl;
	cout << "1. Update the bid's title." << endl;
	cout << "2. Update the bid's fund." << endl;
	cout << "3. Update the bid's amount." << endl;
	cin >> userOption;

	// Loop through user options. Only replace the necessary field.
	// Have a default option in case users enter a non accepted input.
		while(current != nullptr){
			// If its the current node
			if(current -> bid.bidId.compare(correctID)== 0){

				if (userOption == "1") {
					cout <<"Please enter the selected bid's new title: " << endl;
					cin.ignore();
					getline(cin, update);
				    current -> bid.title = update;
				    cout << "\nBid has been successfully updated." << endl;
				}
				else if (userOption == "2" ) {
						cout <<"Please enter the selected bid's new fund: " << endl;
						cin.ignore();
						getline(cin, update);
						current -> bid.fund = update;
						 cout << "\nBid has been successfully updated." << endl;
				}
				else if (userOption == "3") {
						cout <<"Please enter the selected bid's new amount: " << endl;
						cin >> update;
						current -> bid.amount = strToDouble(update, '$');
						 cout << "\nBid has been successfully updated." << endl;
				}
				else{
						cout << "Sorry, your input could not be identified. Please try again." << endl;
				}
			}

			// If bid is smaller than the current one, go left.
			if (correctID.compare(current -> bid.bidId) < 0){
				current = current -> left;
			} // If its larger, go right.
			else{
				current = current -> right;
			}
		}
}


// Place the nodes in correct numerical order.
void BinarySearchTree::inOrder(Node* node) {
	if(node != nullptr){
		// Print the nodes on the left.
		inOrder(node -> left);
		cout << node -> bid.bidId << ": " << node -> bid.title << " | "
				<< node -> bid.amount << " | " << node -> bid.fund << endl;
		// Print the nodes on the right.
		inOrder(node -> right);
	}
}


// Remove a node from the BST.
Node* BinarySearchTree::removeNode(Node* node, string bidId){
	// To avoid crash, if the node is null, just return.
	if(node == nullptr){
		cout << "Could not locate bid " + bidId + "." << endl;
		return node;
	}

	// Go down the left side of the tree.
	if(bidId.compare(node -> bid.bidId) < 0){
		node -> left = removeNode(node -> left, bidId);
	} // Now, right side.
	else if(bidId.compare(node -> bid.bidId) > 0){
		node -> right = removeNode(node -> right, bidId);
	}// No children, so this is a leaf.
	else{

		if(node -> left == nullptr && node -> right == nullptr){
			delete node;
			node = nullptr;
			cout << "Bid has been deleted." << endl;
		} // One child on left side.
		else if(node -> left != nullptr && node -> right == nullptr){
			Node* temp = node;
			node = node -> left;
			delete temp;
			cout << "Bid has been deleted." << endl;
		} // One child on right side.
		else if(node -> right != nullptr && node -> left == nullptr){
			Node* temp = node;
			node = node -> right;
			delete temp;
			cout << "Bid has been deleted." << endl;
		} // Two children.
		else{
			Node* temp = node -> right;
			while(temp -> left != nullptr){
				temp = temp -> left;
			}
				node -> bid = temp -> bid;
				node -> right = removeNode(node -> right, temp ->bid.bidId);
		}
	}
	return node;
}


// Size function to determine the number of bids.
void BinarySearchTree::Size(int number){
	// Output the number of bids read from loadBids.
	cout << number << " bids read." << endl;
}


//============================================================================
// Static methods used for testing
//============================================================================


// Display the bid information to the console (std::out).
// @param bid struct containing the bid info.
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
            << bid.fund << endl;
    return;
}


// Load a CSV file containing bids into a container
// @param csvPath the path to the CSV file to load.
// @return a container holding all the bids read.
int loadBids(string csvPath, BinarySearchTree* bst, int largestValue) {

    cout << "Loading CSV file " << csvPath << endl;
    int number = 0;
    int bidIdInt;

    csv::Parser file = csv::Parser(csvPath);        // Initialize the CSV Parser using the given path.

    cout << "" << endl;

    // Loop to read rows of a CSV file.
    try {
        for (unsigned int i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids.
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            bidIdInt = stoi(bid.bidId);
            if(bidIdInt > largestValue){
            	largestValue = bidIdInt;
            }

            ++number;                            // Increment number.
            bst->Insert(bid);                    // Push new bid to the end.
        }
    } catch (csv::Error &e) {
        std::cerr << e.what() << std::endl;
    }
    bst -> Size(number);

    return largestValue;
}

// Simple C function to convert a string to a double
// after stripping out unwanted char.
// credit: http://stackoverflow.com/a/24875936
// @param ch The character to strip out
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

///// The one and only main() method. //////
int main(int argc, char* argv[]) {

    // Process command line arguments.
    string csvPath, bidKey;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        bidKey = "98109";
        break;
    case 3:
        csvPath = argv[1];
        bidKey = argv[2];
        break;
    default:
        csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
        bidKey = "98109";
    }

    // Define a timer variable.
    clock_t ticks;

    // Define the largest bid ID.
    int largestValue = 0;

    // Variable used to update a selected bid.
    string updateBid;

    // Define a binary search tree to hold all bids
    BinarySearchTree* bst = NULL;

    Bid bid;

    // Provide users a menu of options to select from.
    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Find Bid" << endl;
        cout << "  4. Remove Bids" << endl;
        cout << "  5. Add Bids" << endl;
        cout << "  6. Update Bids" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        // Determine which actions to take based on the user's selection.
        switch (choice) {

        case 1:
        	// LOAD BIDS.
            bst = new BinarySearchTree();
            ticks = clock();                                      // Initialize a timer before loading bids.

            largestValue = loadBids(csvPath, bst, largestValue);  // Complete the method call to load the bids.

            // Calculate elapsed time and display result.
            ticks = clock() - ticks;                              // Current clock ticks minus starting clock ticks.
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:
        	// DISPLAY BIDS.
        	// Do not display bids unless they have already been loaded.
        	if (bst == NULL) {
        		cout << "\nPlease load bids before completing this action!!!" << endl;
        	}
        	else {
        		bst->InOrder();                                  // Point to InOrder function.
        	}
            break;

        case 3:
        	// FIND BIDS.
            ticks = clock();                                     // Initialize a timer before loading bids.

            // Do not allow users to find a bid unless they have been loaded.
            if (bst == NULL) {
            	cout << "\nPlease load bids before completing this action!!!" << endl;
            }
            else {
            	cout << "Please enter the ID of the bid you would like to find: " << endl;
            	cin >> bidKey;
            	bid = bst->Search(bidKey);                      // Point to Search function.

            	ticks = clock() - ticks; // current clock ticks minus starting clock ticks

            	// If the bid has been removed or does not exist, inform the user.
            	if (!bid.bidId.empty()) {
            		displayBid(bid);
            	}
            	else
            	{
            		cout << "Bid Id " << bidKey << " not found." << endl;
            	}

            	// Display the time it took to complete this action.
            	cout << "time: " << ticks << " clock ticks" << endl;
            	cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            }
            break;

        case 4:
        	// REMOVE BIDS.
        	// Do not allow users to find a bid unless they have been loaded.
        	if (bst == NULL) {
        		cout << "\nPlease load bids before completing this action!!!" << endl;
        	}
        	 else {
             	cout << "Please enter the ID of the bid you would like to remove: " << endl;
             	cin >> bidKey;
        		bst->Remove(bidKey);                          // Point to Remove function.
        	}
            break;

        case 5:

        	// ADD BIDS.
        	// Do not allow users to find a bid unless they have been loaded.
        	if (bst == NULL) {
        		cout << "\nPlease load bids before completing this action!!!" << endl;
        	}
        	else {
        		largestValue = bst->createBid(largestValue);           // Point to Create function.
        		cout << "\nBid has been successfully added." << endl;
        	}
        	break;

        case 6:
        	// UPDATE BIDS.
        	// Do not allow users to find a bid unless they have been loaded.
        	if (bst == NULL) {
        		cout << "\nPlease load bids before completing this action!!!" << endl;
        	}
        	else {
        	   cout << "\nPlease enter the Bid ID for the bid you would like to update: " << endl;
        	   cin >> updateBid;
        	   bid = bst->Search(updateBid);                                   // Find the correct bid first.

        	   // Ensure the bid the user is searching for does exist.
        	   if (!bid.bidId.empty()) {
        		   cout << "\nSelected Bid: " << endl;
        		   displayBid(bid);                                            // Display selected bid.
        		   bst->Update(bid);                                           // Point to Update function.
        	   }
        	   else {                                                          // Bid was not found.
        		   cout << "Bid Id " << updateBid << " not found." << endl;
        	   }
        	}

        	break;

        case 9:
        	break; // Simply exit the while loop to exit.

        default:
        	// If the user incorrectly responds to menu, we have a safeguard in place.
        	cout << "Sorry, we could not understand your input. Please try again" << endl;
        	break;
        }
    }
    cout << "Goodbye!!!" << endl;
	return 0;
}
