//=====================================================================================
// Name        : VectorSorting.cpp
// Author      : Avery Lutz
// Date        : June 19, 2022
// Class       : CS-499-T5649
// Artifact    : Two
// Version     : 2.0
// Ability     : Data Structures and Algorithms
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Utilize vector sorting to manage contents of an Excel spreadsheet.
// Features    : Load a list of bids, add new bids, update, delete, and sort bids.
//=====================================================================================

#include <algorithm>
#include <iostream>
#include <time.h>
#include <string>

#include "CSVparser.hpp"

using namespace std;

//=========================================================
// Global definitions visible to all methods and classes
//=========================================================

// Forward declarations.
double strToDouble(string str, char ch);

// Define a structure to hold bid information.
struct Bid {
    string bidId; // Unique identifier.
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

//=========================================
// Static methods used for testing
//=========================================

// Remove an already existing bid within the vector.
vector<Bid> removeBid (vector<Bid> bids, string deleteID) {

	int bidToDelete = 0;

	for (string :: size_type i = 0; i < bids.size(); ++i) {       // Loop through the bids in the vector.
		if (bids.at(i).bidId == deleteID){                        // If we find the desired bid Id, we will update it.
			bidToDelete = i;
		}
	}

	bids.erase(bids.begin() + bidToDelete);                       // Remove bid from the vector.

	// Inform users whether the removal was successful.
	if (bidToDelete != 0) {
		cout << "Bid " + deleteID + " has been removed." << endl;
	}
	else {
		cout << "Bid " + deleteID + " could not be located." << endl;
	}

	return bids;
}



// Update an already existing bid within the vector.
vector<Bid> updateBid (vector<Bid> bids, string updateID) {

	string userOption;                                            // The user's selection for field modification.
	string update;                                                // The user's desired update for the new field.
	int bidToUpdate = 0;                                          // Initialize to 0 so we can check for existence.

	for (string :: size_type i = 0; i < bids.size(); ++i) {       // Loop through the bids in the vector.
		if (bids.at(i).bidId == updateID){                        // If we find the desired bid Id, we will update it.
			bidToUpdate = i;
		}
	}

	if (bidToUpdate != 0) {                                       // Ensure the bid in question actually exists.
	    // Ask the user which field they would like to change.
		cout << "Please select one of the following options by typing a 1, 2, or 3:" << endl;
		cout << "1. Update the bid's title." << endl;
		cout << "2. Update the bid's fund." << endl;
		cout << "3. Update the bid's amount." << endl;
		cin >> userOption;

		// Loop through user options.
		if (userOption == "1") {
			cout <<"Please enter the selected bid's new title: " << endl;
			cin.ignore();
			getline(cin, update);
			bids.at(bidToUpdate).title = update;                 // Update the title of bid within the vector.

		}
		else if (userOption == "2" ) {
			cout <<"Please enter the selected bid's new fund: " << endl;
			cin.ignore();
			getline(cin, update);
			bids.at(bidToUpdate).fund = update;                  // Update the fund of bid within the vector.

		}
		else if (userOption == "3") {
			cout <<"Please enter the selected bid's new amount: " << endl;
			cin >> update;
			bids.at(bidToUpdate).amount = strToDouble(update, '$');      // Update the amount of bid within the vector.

		}
		// User selected an invalid choice.
		else {
			cout <<"Sorry, your input was unrecognizable. Please try again." << endl;
		}
	// User selected a bid that does not exist.
	}
	else {
		cout << "Sorry, the bid you are searching for does not exist." << endl;
	}
		return bids;
}



// Display the bid information to the console (std::out).
// @param bid struct containing the bid info.
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
            << bid.fund << endl;
    return;
}


// Prompt user for bid information using console (std::in)
// @return Bid struct containing the bid info.
Bid getBid(int largestBid ) {
	// Allow user to enter information about new bids.
    Bid bid;

    bid.bidId = to_string(largestBid + 1);        // Set the largest Bid to the next largest ID in the vector.

    cout << "Enter title: ";
    cin.ignore();
    getline(cin, bid.title);                      // Obtain the new bid's title.

    cout << "Enter fund: ";
    getline(cin, bid.fund);                       // Obtain the new bid's fund.

    cout << "Enter amount: ";
    string strAmount;
    cin>> strAmount;
    bid.amount = strToDouble(strAmount, '$');     // Ensure to set the amount to a double as opposed to a string.

    return bid;                                   // Return the newly created bid.
}


// Load a CSV file containing bids into a container.
// @param csvPath the path to the CSV file to load.
// @return a container holding all the bids read.
vector<Bid> loadBids(string csvPath) {
    cout << "Loading CSV file " << csvPath << endl;

    // Define a vector data structure to hold a collection of bids.
    vector<Bid> bids;

    // Initialize the CSV Parser using the given path.
    csv::Parser file = csv::Parser(csvPath);

    try {
        // Loop to read rows of a CSV file
        for (string :: size_type i = 0; i < file.rowCount(); i++) {

            // Create a data structure and add to the collection of bids.
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            // Push this bid to the end.
            bids.push_back(bid);
        }
    } catch (csv::Error &e) {
        std::cerr << e.what() << std::endl;
    }
    return bids;
}

// Implement the quick sort logic over bid.title.

// Partition the vector of bids into two parts, low and high.
// @param bids Address of the vector<Bid> instance to be partitioned.
// @param begin Beginning index to partition.
// @param end Ending index to partition.
int partition(vector<Bid>& bids, int begin, int end) {
	int low = begin;
	int high = end;

	// Middle point is pivot point.
	int pivot = begin + (end - begin) / 2;

	bool done = false;
	while (!done) {

		// Increment low value while its less than pivot.
		while (bids.at(low).title.compare(bids.at(pivot).title)< 0) {
			++low;
		}

		// Decrement high value while its more than pivot.
		while (bids.at(pivot).title.compare(bids.at(high).title) <0) {
			--high;
		}

		if (low >= high) {
			done = true;
		}
		else {
			// Swap the positions of the low and high bids.
			swap(bids.at(low), bids.at(high));

			++low;
			--high;
		}
	}

	// Return this partition' highest value.
	return high;
}


// Perform a quick sort on bid title
// Average performance: O(n log(n))
// Worst case performance O(n^2))

// @param bids address of the vector<Bid> instance to be sorted.
// @param begin the beginning index to sort on.
// @param end the ending index to sort on.
void quickSort(vector<Bid>& bids, int begin, int end) {
	int middle = 0 ;

	// If there is only 0 or 1 bid, all done.
	if (begin >= end) {
		return;
	}

	// Partition separates a low and high part.
	middle = partition(bids, begin, end);

	// Call quickSort recursively with the middle value.
	// Utilize beginning and middle.
	quickSort(bids, begin, middle);
	// Utilize middle + 1 and end.
	quickSort(bids, middle + 1, end);

}

// Implement the selection sort logic over bid.title.

// Perform a selection sort on bid title
// Average performance: O(n^2))
// Worst case performance O(n^2)).
// @param bid address of the vector<Bid>
// instance to be sorted.
void selectionSort(vector<Bid>& bids) {
	// Index for the current minimum bid.
	int min;

	// Position in the bids that separate sorted and unsorted.
	for (unsigned position = 0; position < bids.size(); ++position){
		min = position;

		// Look for the next smallest bid in the vector.
		for (unsigned j = position + 1; j < bids.size(); ++j) {
			if (bids.at(j).title.compare(bids.at(min).title)< 0) {
				min = j;
			}
		}

		// Swap the positions so the small value is moved closer to head of list.
		if ((unsigned)min != position) {
			swap(bids.at(position), bids.at(min));
		}
	}
}

/// Simple C function to convert a string to a double
// after stripping out unwanted char.
// credit: http://stackoverflow.com/a/24875936
// @param ch The character to strip out.
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

// The one and only main() method.
int main(int argc, char* argv[]) {

    // Process command line arguments.
    string csvPath;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        break;
    default:
        csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
    }

    // Define a vector to hold all the bids.
    vector<Bid> bids;

    int largestBidID = 0;
    int currentID;
	Bid newBid;
	string userInputID;

    // Define a timer variable.
    clock_t ticks;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Selection Sort All Bids" << endl;
        cout << "  4. Quick Sort All Bids" << endl;
        cout << "  5. Add Bid" << endl;
        cout << "  6. Update Bid" << endl;
        cout << "  7. Remove Bid" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            // Initialize a timer variable before loading bids.
            ticks = clock();

            // Complete the method call to load the bids.
            bids = loadBids(csvPath);

            cout << bids.size() << " bids read" << endl;

            // Calculate elapsed time and display result.
            ticks = clock() - ticks; // Current clock ticks minus starting clock ticks
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;

            for (string :: size_type i = 0; i < bids.size(); i++){

            	currentID = stoi(bids[i].bidId);

            	if (currentID > largestBidID){
            		largestBidID = currentID;
            	}
            }

            break;

        case 2:

        	if (bids.size() != 0){
        		for (string :: size_type i = 0; i < bids.size(); ++i) {       // Loop and display the bids read.
        			displayBid(bids[i]);
        		}
        		cout << endl;
        	}
        	else {
        		cout << "Please Load Bids First!" << endl;
        	}

            break;

        // Invoke the selection sort and report timing results.
        case 3:
            // Initialize a timer variable before loading bids.
        	ticks = clock();

        	if (bids.size() != 0){
        		// Complete the method call to sort the bids.
        		selectionSort(bids);

        		cout << bids.size() << " bids read" << endl;

        		// Calculate elapsed time and display result.
        		ticks = clock() - ticks;                              // Current clock ticks minus starting clock ticks.
        		cout << "time: " << ticks << " clock ticks" << endl;
        		cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
        	}
        	else {
        		cout << "Please Load Bids First!" << endl;
        	}

            break;

        // Invoke the quick sort and report timing results.
        case 4:
            // Initialize a timer variable before loading bids.
            ticks = clock();

            // Complete the method call to sort the bids.
            if (bids.size() != 0){
            	quickSort(bids, 0, bids.size()-1);

            	cout << bids.size() << " bids read" << endl;

            	// Calculate elapsed time and display result.
            	ticks = clock() - ticks;                                // Current clock ticks minus starting clock ticks.
            	cout << "time: " << ticks << " clock ticks" << endl;
            	cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            }
        	else {
        		cout << "Please Load Bids First!" << endl;
        	}

            break;

        case 5:

        	if (bids.size() != 0){

        		newBid = getBid(largestBidID);           // Create a single bid.
        		bids.push_back(newBid);                  // Add the bid to the end of the vector.
        		largestBidID++;                          // Increment the largest bid value.
        	}
        	else{
        		cout << "Please Load Bids First!" << endl;
        	}
        	break;

        case 6:
        	if (bids.size() != 0){
        		cout << "What is the ID for the bid you would like to update? " << endl;
        		cin >> userInputID;

        		bids = updateBid(bids, userInputID);         // Call the update function.
        	}
        	else{
        		cout << "Please Load Bids First!" << endl;
        	}
        	break;

        case 7:

        	if (bids.size() != 0){
        		cout << "What is the ID for the bid you would like to delete? " << endl;
        		cin >> userInputID;

        		bids = removeBid(bids, userInputID);         // Call the update function.
        	}
        	else{
        		cout << "Please Load Bids First!" << endl;
        	}
        	break;


        case 9:
        	break; // User would simply like to exist the program.

        default:
        	// User enters an unrecognizable option.
        	cout << "Sorry, your input could not be recognized. Please try again." << endl;
        }
    }
    cout << "Goodbye!!!" << endl;
    return 0;
}
