//===========================================================================================
// Name        : HashTable.cpp
// Author      : Avery Lutz
// Date        : June 19, 2022
// Class       : CS-499-T5649
// Artifact    : Two
// Version     : 2.0
// Ability     : Data Structures and Algorithms
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Utilize a hash table to manage contents of an Excel spreadsheet.
// Features    : Load a list of bids, add new bids, update, delete, and find existing bids.
//===========================================================================================

#include <algorithm>
#include <climits>
#include <iostream>
#include <string>              // atoi
#include <time.h>

#include "CSVparser.hpp"

using namespace std;

//==========================================================
// Global definitions visible to all methods and classes
//==========================================================

const unsigned int DEFAULT_SIZE = 179;

// Forward declarations.
double strToDouble(string str, char ch);

struct Bid {                                              // Define a structure to hold bid information.
    string bidId;                                         // Unique identifier.
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

//==========================================================
// Hash Table class definition
//==========================================================

// Define a class containing data members and methods to
// implement a hash table with chaining.
class HashTable {

private:

	struct Node {                                         // Define structures to hold bids.
		Bid bid;
		unsigned key;
		Node* next;

		Node() {                                          // Default constructor with the name of the class.
			key = UINT_MAX;
			next = nullptr;
		}

		Node(Bid aBid): Node() {                          // Constructor with a bid.
			bid = aBid;
		}

		Node(Bid aBid, unsigned aKey): Node(aBid) {       // Constructor with a bid and a key.
			key = aKey;
		}
	};

	vector<Node> nodes;                                   // Define a vector to store the bids.
	unsigned tableSize = DEFAULT_SIZE;

    unsigned int hash(int key);

public:
    HashTable();
    HashTable(unsigned size);
    virtual ~HashTable();
    void Insert(Bid bid);
    void PrintAll();
    int createBid(int largestBidId);
    void Update(Bid bid);
    void Remove(string bidId);
    Bid Search(string bidId);
    size_t Size();
};

HashTable::HashTable() {                                  // Default constructor.
	nodes.resize(tableSize);                              // Initialize the structures used to hold bids
}

HashTable::HashTable(unsigned size) {                     // Destructor.
	this -> tableSize = size;
	nodes.resize(tableSize);
}

HashTable::~HashTable() {
	nodes.erase(nodes.begin());                           // Implement logic to free storage when class is destroyed.
}


// Calculate the hash value of a given key.
// Note that key is specifically defined as
// unsigned int to prevent undefined results
// of a negative list index.
// @param key The key to hash
// @return The calculated hash.
unsigned int HashTable::hash(int key) {
	return key % tableSize;                               // Logic to calculate a hash value.
}


// Insert a bid.
// @param bid The bid to insert.
void HashTable::Insert(Bid bid) {

	unsigned key = hash(atoi(bid.bidId.c_str()));         // Implement logic to insert a bid

	Node* oldNode = &(nodes.at(key));                     // Test and retrieve node with key.

	if (oldNode == nullptr){                              // If there is no entry for the current key.
		Node* newNode = new Node(bid, key);
		nodes.insert(nodes.begin() + key, (*newNode));
	}
	else {
		if (oldNode -> key == UINT_MAX) {                 // A node was found.
			oldNode -> key = key;
			oldNode -> bid = bid;
			oldNode -> next = nullptr;
		}
		else {                                           // Find the next available node.
			while (oldNode -> next != nullptr) {
				oldNode = oldNode -> next;
			}
			oldNode -> next = new Node(bid, key);
		}
	}
}


// Print all bids.
void HashTable::PrintAll() {                                                  // Implement logic to print all bids.

	 for (auto iter = nodes.begin(); iter != nodes.end(); ++iter) {           // Loop through each key beginning with the first node.

		 if (iter->key != UINT_MAX) {
			 cout << "Key " << iter->key << ": " << iter->bid.bidId << " | "
	         << iter->bid.title << " | " << iter->bid.amount << " | "
	         << iter->bid.fund << endl;
	         Node* node = iter->next;

	         while (node != nullptr) {                                        // While the node is not empty, loop through for chained items.
	        	 cout << "    " << node->key << ": " << node->bid.bidId
	             << " | " << node->bid.title << " | " << node->bid.amount
	             << " | " << node->bid.fund << endl;
	             node = node->next;
	        }
	     }
	 }
}

void displayBid(Bid bid);                                                     // Prototype for createBid method.

// Add a bid to the exisitng list.
// @param largestBidId to determine the new ID.
int HashTable::createBid(int largestBidId){

		string amount;                                                        // Declare the variables required for method.
		int newLargest = (largestBidId + 1);
		Bid bid;

		// Obtain the different bid categories from the user.
		bid.bidId = to_string(newLargest);
		cout << "\nWhat is the title of the bid you would like to enter? " << endl;
		cin.ignore();
		getline(cin, bid.title);

		cout << "What is the fund of the bid you would like to enter? " << endl;
		getline(cin, bid.fund);

		cout << "What is the amount of the bid you would like to enter? (please exclude $) " << endl;
		cin >> amount;
		bid.amount = strToDouble(amount, '$');

		cout << "Here is your new Bid: " << endl;                             // Display new bid to the user & add bid to the existing bst.
		displayBid(bid);
		Insert(bid);

		return newLargest;                                                    // Return the new largest bid for future use.
}


// Update a bid.
// @param bid The bid we are updating.
void HashTable::Update(Bid bid){

	string userOption;                                                // The user's selection for field modification.
	string update;                                                    // The update for the new field.
	string correctID = bid.bidId;                                     // Variable to match against node.

    unsigned key = hash(atoi(bid.bidId.c_str()));                     // Find key associated with bid in hash table.

    Node* node = &(nodes.at(key));                                    // Retrieve node with key.

	// Ask the user which field they would like to change.
	cout << "Please select one of the following options by typing a 1, 2, or 3:" << endl;
	cout << "1. Update the bid's title." << endl;
	cout << "2. Update the bid's fund." << endl;
	cout << "3. Update the bid's amount." << endl;
	cin >> userOption;

	    while (node != nullptr){                                                       // Find the node with the correct bid ID and correct key.
		if (node -> key != UINT_MAX && node->bid.bidId.compare(correctID) == 0){

			if (userOption == "1") {                                                           // Loop through user options.
				cout <<"Please enter the selected bid's new title: " << endl;
				cin.ignore();
				getline(cin, update);                                                          // Obtain update for structure field.
				node -> bid.title = update;
			}
			else if (userOption == "2" ) {
					cout <<"Please enter the selected bid's new fund: " << endl;
					cin.ignore();
					getline(cin, update);
					node -> bid.fund = update;
			}
			else if (userOption == "3") {
					cout <<"Please enter the selected bid's new amount: " << endl;
					cin >> update;
					node -> bid.amount = strToDouble(update, '$');
			}
			else{                                                                  // Default option if a non valid value is entered.
					cout <<"Sorry, your input was unrecognizable. Please try again." << endl;
				}
	    }
		 node = node -> next;                                                     // If it is not correct ID, go to next node.
	}
}



// Remove a bid.
// @param bidId The bid id to search for.
void HashTable::Remove(string bidId) {
	unsigned key = hash(atoi(bidId.c_str()));                         // Logic to remove a bid.
	nodes.erase(nodes.begin() + key);
}


// Search for the specified bidId
// @param bidId The bid id to search for
Bid HashTable::Search(string bidId) {
    Bid bid;

    // Logic to search for and return a bid.

    unsigned key = hash(atoi(bidId.c_str()));                         // Calculate the correct key for the bid.

    Node* node = &(nodes.at(key));                                    // Retrieve node with key.

    if (node == nullptr || node -> key == UINT_MAX) {                 // If entry is not found.
        return bid;
     }

    if (node != nullptr && node -> key != UINT_MAX                    // If a node is found.
    		&& node -> bid.bidId.compare(bidId)== 0) {
    	return node -> bid;
    }

    while (node != nullptr) {                                          // Follow nodes until there is a match.
    	if (node -> key != UINT_MAX && node->bid.bidId.compare(bidId) == 0){
    		return node -> bid;
    	}
    	node = node -> next;
    }

    return bid;
}


// Size function to determine the number of bids.
size_t HashTable::Size(){
	return nodes.size();
}

//============================================================================
// Static methods used for testing
//============================================================================


// Display the bid information to the console (std::out)
// @param bid struct containing the bid info.
void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
            << bid.fund << endl;
    return;
}


// Load a CSV file containing bids into a container
// @param csvPath the path to the CSV file to load
// @return a container holding all the bids read
int loadBids(string csvPath, HashTable* hashTable, int largestBidId) {
    cout << "Loading CSV file " << csvPath << endl;

    int currentBidIdInt;                                                 // Declare variable to represent the current bid.
    csv::Parser file = csv::Parser(csvPath);                             // Initialize the CSV Parser using the given path.

    vector<string> header = file.getHeader();                            // Read and display header row.
    for (auto const& c : header) {
        cout << c << " | ";
    }
    cout << "" << endl;

    try {

        for (unsigned int i = 0; i < file.rowCount(); i++) {              // Loop to read rows of a CSV file.

            Bid bid;                                                      // Create a data structure and add to the collection of bids
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            currentBidIdInt = stoi(bid.bidId);
            if(currentBidIdInt > largestBidId) {
            	largestBidId = currentBidIdInt;
            }
            hashTable->Insert(bid);                                       // Push this bid to the end.
        }

    } catch (csv::Error &e) {
        std::cerr << e.what() << std::endl;
    }

    return largestBidId;
}


// Simple C function to convert a string to a double
// after stripping out unwanted char.
// credit: http://stackoverflow.com/a/24875936
// @param ch The character to strip out.
double strToDouble(string str, char ch) {
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

// The one and only main() method.
int main(int argc, char* argv[]) {

    // Process command line arguments.
    string csvPath, searchValue;
    switch (argc) {
    case 2:
        csvPath = argv[1];
        searchValue = "98109";
        break;
    case 3:
        csvPath = argv[1];
        searchValue = argv[2];
        break;
    default:
        csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
        searchValue = "98109";
    }


    clock_t ticks;                                                   // Define a timer variable.
    HashTable* bidTable = NULL;                                      // Define a hash table to hold all the bids.
    int largestBidId = 0;                                            // Define a variable for largest ID.
    string updateBid;                                                // Variable used to update a selected bid.
    Bid bid;

    int choice = 0;
    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Find Bid" << endl;
        cout << "  4. Remove Bid" << endl;
        cout << "  5. Add Bid" << endl;
        cout << "  6. Update Bid" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {

        case 1:
            bidTable = new HashTable();

            ticks = clock();                                              // Initialize a timer variable before loading bids

            largestBidId = loadBids(csvPath, bidTable, largestBidId);     // Complete the method call to load the bids

            cout << bidTable ->Size() << " bids read" << endl;

            // Calculate elapsed time and display result
            ticks = clock() - ticks;                                      // Current clock ticks minus starting clock ticks.
            cout << "time: " << ticks << " clock ticks" << endl;
            cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            break;

        case 2:

        	// Do not display bids unless they have already been loaded.
        	if (bidTable == NULL) {
        		cout << "\nPlease load bids before completing this action!!!" << endl;
        	}
        	else {
        		bidTable->PrintAll();
        	}
            break;

        case 3:
            ticks = clock();

            // Do not find bids unless they have already been loaded.
            if (bidTable == NULL) {
            	cout << "\nPlease load bids before completing this action!!!" << endl;
            }
            else {
            	cout << "Please enter the ID of the bid you would like to find: " << endl;
            	cin >> searchValue;
            	bid = bidTable->Search(searchValue);                             // Point bidTable to Search Function

            	ticks = clock() - ticks;                                         // Current clock ticks minus starting clock ticks.

            	if (!bid.bidId.empty()) {
            		displayBid(bid);
            	}
            	else {
            		cout << "Bid Id " << searchValue << " not found." << endl;
            	}

            	cout << "time: " << ticks << " clock ticks" << endl;
            	cout << "time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
            }
            	break;

        case 4:

        	 // Do not remove bids unless they have already been loaded.
            if (bidTable == NULL) {
            	cout << "\nPlease load bids before completing this action!!!" << endl;
        	}
        	else {
            	cout << "Please enter the ID of the bid you would like to remove: " << endl;
            	cin >> searchValue;

            	bid = bidTable->Search(searchValue);                           // Determine whether bid exists.

            	if (!bid.bidId.empty()) {
            		bidTable->Remove(searchValue);                             // Point bidTable to Remove Function.
            		cout << "Bid has been deleted." << endl;
            	}
            	else {
            		cout << "Bid does not exist." << endl;                      // Inform user if bid already is gone.
            	}
        	}
            break;


        case 5:

        	   // Do not add bids unless they have already been loaded.
            if (bidTable == NULL) {
            	cout << "\nPlease load bids before completing this action!!!" << endl;
        	}
        	else {
        		largestBidId = bidTable->createBid(largestBidId);                // Point to Create function.
        		cout << "\nBid has been successfully added." << endl;            // Inform user that addition worked.
        	}
        	break;

        case 6:

        	// Do not update bids unless they have already been loaded.
            if (bidTable == NULL) {
            	cout << "\nPlease load bids before completing this action!!!" << endl;
        	}
        	else {
         	   cout << "\nPlease enter the Bid ID for the bid you would like to update: " << endl;
         	   cin >> updateBid;
         	   bid = bidTable->Search(updateBid);                                      // Find the bid to update.

        	   if (!bid.bidId.empty()) {                                               // Ensure the bid the user is searching for does exist.
        		   cout << "\nSelected Bid: " << endl;
        		   displayBid(bid);                                                    // Display selected bid.
           	       bidTable->Update(bid);                                              // Point to Update function.
        		   cout << "\nBid has been successfully updated." << endl;             // Inform users that update worked.
        	   }
        	   else                                                                    // Bid was not found.
        	   {
        		   cout << "Bid Id " << updateBid << " not found." << endl;
        	   }
        	}
        	break;

        case 9:
        	break;

        default:                                                                       // User's input was invalid.
        	cout << "\nSorry, we could not recognize your input. Please try again." << endl;
        	break;
        }
    }

    cout << "Goodbye!!!" << endl;

    return 0;
}
